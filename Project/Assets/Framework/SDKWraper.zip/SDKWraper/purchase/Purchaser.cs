﻿//Purchaser.GetInstance ,单例模式
//1.初始化：InitializePurchaser
//	OnInitialized，初始化成功后才能使用，否则不能使用
//	OnInitializeFailed
//
//2.购买：purchase
//	ProcessPurchase，购买成功，在此函数里验证
//	OnPurchaseFailed，购买失败
//3.restore:OnInitialized函数的后半段，restore以前购买的商品
//4.m_ProductCollection  返回商店所有的商品
// 

using System;
using System.Collections;
using System.Collections.Generic;
using Framework.Tables;
using UnityEngine;
using UnityEngine.Purchasing;
using UnityEngine.Purchasing.Security;
using UnityEngine.SceneManagement;
using System.Linq;
using Framework.Storage;

public class Purchaser : D_MonoSingleton<Purchaser>, IStoreListener
{

    public static string Purchaser_Initialized_Sucess = "purchase_init_sucesss";
    public static string Purchaser_Initialized_Fail = "purchase_init_fail";

	public static string Purchaser_Purchase_Sucess = "purchaser_purchase_sucess";
    public static string Purchaser_Purchase_Fail = "purchaser_purchase_fail";

    public static string Purchaser_Restore_Sucess = "purchase_restore_sucesss";
    public static string Purchaser_Restore_Fail = "purchase_restore_fail";

    // Unity IAP objects 
    private IStoreController m_Controller;
    private IAppleExtensions m_AppleExtensions;
    public ProductCollection m_ProductCollection;

    public bool initSucess;
    public TableStore curShopItem;

    public List<Product> products = new List<Product>();

    public void OnInitialized(IStoreController controller, IExtensionProvider extensions)
    {
        //Log("Billing sucessed to initialize!");
        m_Controller = controller;
        m_AppleExtensions = extensions.GetExtension<IAppleExtensions>();
        m_ProductCollection = controller.products;
        initSucess = true;
        //Log("Available items:");
        foreach (Product item in controller.products.all)
        {
            if (item.availableToPurchase)
            {
                //Log(item.metadata.localizedTitle);
                //StoreManager.Instance.AddLocalProduct(new LocalProductInfo(item.definition.id, item.metadata.localizedTitle,
                //    item.metadata.localizedDescription,
                //    item.metadata.isoCurrencyCode,
                //    item.metadata.localizedPrice.ToString(),
                //    item.metadata.localizedPriceString
                //));
                products.Add(item);
            }
        }
        //restore
//        m_AppleExtensions.RestoreTransactions(result =>
//        {
//            if (result)
//            {
//
//            }
//            else
//            {
//
//            }
//        });
        
    }
    public void restoreIOS()
    {

        m_AppleExtensions.RestoreTransactions(result =>
        {
            if (result)
            {
            }
            else
            {
            }
        });
    }




    /// <summary>
    /// Called when Unity IAP encounters an unrecoverable initialization error.
    ///
    /// Note that this will not be called if Internet is unavailable; Unity IAP
    /// will attempt initialization until it becomes available.
    /// </summary>
    public void OnInitializeFailed(InitializationFailureReason error)
    {
        initSucess = false;
        //Log("Billing failed to initialize!");
        switch (error)
        {
            case InitializationFailureReason.AppNotKnown:
                //LogError("Is your App correctly uploaded on the relevant publisher console?");
                UIManager.Inst.ShowMessage(LanguageTool.Get("pay_init_error"));
                break;
            case InitializationFailureReason.PurchasingUnavailable:
                // Ask the user if billing is disabled in device settings.
                //Log("Billing disabled!");
                UIManager.Inst.ShowMessage(LanguageTool.Get("billing_disabled"));
                break;
            case InitializationFailureReason.NoProductsAvailable:
                // Developer configuration error; check product metadata.
                //Log("No products available for purchase!");
                UIManager.Inst.ShowMessage(LanguageTool.Get("no_products"));
                break;
        }
    }

    public PurchaseProcessingResult ProcessPurchase(PurchaseEventArgs e)
    {
        UIManager.Inst.hideWaiting();
        string storeId = e.purchasedProduct.definition.id;
        bool validPurchase = true; // Presume valid for platforms with no R.V.

        // Unity IAP's validation logic is only included on these platforms.
#if UNITY_ANDROID || UNITY_IOS || UNITY_STANDALONE_OSX
        // Prepare the validator with the secrets we prepared in the Editor
        // obfuscation window.
        var validator = new CrossPlatformValidator(GooglePlayTangle.Data(),
            AppleTangle.Data(), Application.identifier);

        List<PurchaseResultInfo> purchaseResults = new List<PurchaseResultInfo>();
        try
        {
            // On Google Play, result has a single product ID.
            // On Apple stores, receipts contain multiple products.
            var result = validator.Validate(e.purchasedProduct.receipt);
            // For informational purposes, we list the receipt(s)
            //Log("Receipt is valid. Contents:");
            foreach (IPurchaseReceipt productReceipt in result)
            {
                PurchaseResultInfo pr = new PurchaseResultInfo();
                pr.productID = productReceipt.productID;
                pr.purchaseDate = productReceipt.purchaseDate.ToString();
                pr.transactionID = productReceipt.transactionID;
                purchaseResults.Add(pr);
            }
        }
        catch (IAPSecurityException)
        {
            //Log("Invalid receipt, not unlocking content");
            validPurchase = false;
        }
        Log("Purchaser validPurchase:"+validPurchase);
        Log("Purchaser storeId:" + storeId);
        int productId = 0;
        TableStore storeItem = Table.Store.GetAll().FirstOrDefault(x => x.StoreId == storeId);
        if (validPurchase && storeItem != null)
        {
            
            productId = storeItem.Id;
            
            //支付打点
            try
            {
                TableBI.PaySuccess(productId.ToString(), storeId, storeItem.Price, DataManager.Inst.userInfo.Level,
                    DataManager.Inst.userInfo.Coins, DataManager.Inst.userInfo.PayTotal,
                    AssetBundleConfig.Inst.AppChannel.ToString());
            }
            catch (Exception exception)
            {
                DebugUtil.LogError("支付打点失败, productId=" + productId);
                DebugUtil.LogError(exception.StackTrace);
            }

            showGainProductPanel(storeItem);
            
            //支付总计累计
            DataManager.Inst.userInfo.PayTotal += storeItem.Price;

            //DataManager.Inst.userInfo.AddCoin(storeItem.Coin);
            //foreach (var item in storeItem.Content)
            //{
            //    DataManager.Inst.userInfo.ChangeGoodsCount(item.Key,item.Value);
            //}
        }
#if UNITY_EDITOR
        if (!validPurchase && storeItem != null)
        {
            showGainProductPanel(storeItem);
        }
#endif

        if (validPurchase)
        {
            StaticPurchaseSucess(productId);
            return PurchaseProcessingResult.Complete;
        }
        else
        {
            //UiManager.Instance.Pop(Pop.PopPayFail, PopPayFailView.PAY_FAIL);
            StaticPurchaseFail(productId);
            return PurchaseProcessingResult.Pending;
        }
#else
 return PurchaseProcessingResult.Complete;
#endif
    }
   void showGainProductPanel(TableStore storeItem)
    {
        StorageManager.Inst.GetStorage<StorageUserInfo>().HasFirstPurchase = true;
        Dictionary<int, int> ps = new Dictionary<int, int>();
        foreach (var item in storeItem.Content)
        {
            ps.Add(item.Key, item.Value);
        }
        if (storeItem.Coin > 0)
            ps.Add(Table.GoodsId.Coin, storeItem.Coin);

        UIManager.Inst.ShowUI(UIModuleEnum.GameRewardCardPanel, false, ps,true);
    }
    // This will be called is an attempted purchase fails.
    public void OnPurchaseFailed(Product item, PurchaseFailureReason r)
    {
        UIManager.Inst.hideWaiting();
        if (r == PurchaseFailureReason.UserCancelled)
        {
//            BlastAnalytics.Analytics(STATISTIC_EVENT_CODE.PAY_CANCEL, UserInfoManager.Instance.userInfo.level,
//                curShopItem.id, (int)curShopItem.price * 100, GameBase.Instance.InGame() ? 1 : 0, -1, -1, -1,
//                r.ToString());
        }
        else
        {
            StaticPurchaseFail(0, r);
            UIManager.Inst.ShowMessage(LanguageTool.Get("pay_fail_pls_try"));
        }
    }

    private void StaticPurchaseFail(int productId = 0, PurchaseFailureReason r = PurchaseFailureReason.Unknown)
    {
        //if (curShopItem != null)
        //{
        //    BlastAnalytics.Analytics(STATISTIC_EVENT_CODE.PAY_FAIL, UserInfoManager.Instance.userInfo.level,
        //        curShopItem.id, (int)curShopItem.price * 100, GameBase.Instance.InGame() ? 1 : 0, -1, -1, -1,
        //        r.ToString());
        //}
        //else
        //{
        //    if (curConfBundle != null)
        //    {
        //        BlastAnalytics.Analytics(STATISTIC_EVENT_CODE.PAY_FAIL, UserInfoManager.Instance.userInfo.level,
        //            curConfBundle.id, (int)curConfBundle.price * 100, GameBase.Instance.InGame() ? 1 : 0, -1, -1, -1,
        //            r.ToString());
        //    }
        //    else
        //    {
        //        BlastAnalytics.Analytics(STATISTIC_EVENT_CODE.PAY_FAIL, UserInfoManager.Instance.userInfo.level);
        //    }
        //}
    }

    private void StaticPurchaseSucess(int productId = 0)
    {
        //if (curShopItem != null)
        //{
        //    BlastAnalytics.Analytics(STATISTIC_EVENT_CODE.PAY_SUCCESS, UserInfoManager.Instance.userInfo.level,
        //        curShopItem.id, (int)(curShopItem.price * 100), GameBase.Instance.InGame() ? 1 : 0);
        //}
        //if (curConfBundle != null)
        //{
        //    BlastAnalytics.Analytics(STATISTIC_EVENT_CODE.PAY_SUCCESS, UserInfoManager.Instance.userInfo.level,
        //        curConfBundle.id, (int)(curConfBundle.price * 100), GameBase.Instance.InGame() ? 1 : 0);
        //}
    }



    public void InitializePurchaser()
    {
        var module = StandardPurchasingModule.Instance();
        //module.useMockBillingSystem = true;
        var builder = ConfigurationBuilder.Instance(module);

        string apusKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqsOa1I0ADV54Z2JaV+/eIbyljbJOjR5nte9zeE3wvJDK4A7maP3brArlzJR61/LZJ07Enp05m29V29zN6qydpFLt7ir+p6CEkM/LfGBfUc0NhEcI71GxNrBi9rZjwYFMVOYNbhzk9SvnrBi1R3gseRutWS4MhkkaZ2zANThkBrxe1js1AAn7ePZCCKExWs2WHNQA/SiiXoAdrCtt8iznvDwML5FMyRgkX7LwENwQeeb4TGZ6cVxNgtO6GfklmxNPqAtmiUhdcBPGFSQij2kqtchJfRLRg2fj3W0sFEmuzOq8wSpRHbg7hE1/Vg7bEEdn3utDe+OUIbTKOwwDX3gGDQIDAQAB";
        //string baguoKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmpe/u/8scm12Av3wM41oPbjBr5CwPo7zh9/MgFCPMz8rfH2OJsLMEDd61OJInI/pvrRLyuYiO+UxS7vX86/7gsMdLgozJ/yAmWyWpBbGfdM7pBNFA2ieXkVvd94o3VjJbshS48qjiI/wAmKeiWj4UqY5vl5pzJMeOXYhmzKKLsP5Ro5w64RVN3RQ27jkc7m8OmpnhLCbpnOPCX9fhm144EWIqn2iM7rwHztpOshdG2qbA1yEgOMg6CnjlbhHM2R5YwpBNyF0RU8Zpk6AWe68i9uVoRnnr6cnVr26KyBKVSxrderAZR/c+UevD77krNsd8BPNDWcNTnRnGi9fVtIWBwIDAQAB";
        builder.Configure<IGooglePlayConfiguration>().SetPublicKey(apusKey);


        builder.AddProduct("gold1", ProductType.Consumable, new IDs
        {
            {"gold1", GooglePlay.Name},
            {"gold1", AppleAppStore.Name}
        });
        builder.AddProduct("gold2", ProductType.Consumable, new IDs
        {
            {"gold2", GooglePlay.Name},
            {"gold2", AppleAppStore.Name}
        });
        builder.AddProduct("gold3", ProductType.Consumable, new IDs
        {
            {"gold3", GooglePlay.Name},
            {"gold3", AppleAppStore.Name}
        });
        builder.AddProduct("gold4", ProductType.Consumable, new IDs
        {
            {"gold4", GooglePlay.Name},
            {"gold4", AppleAppStore.Name}
        });
        builder.AddProduct("gold5", ProductType.Consumable, new IDs
        {
            {"gold5", GooglePlay.Name},
            {"gold5", AppleAppStore.Name}
        });
        builder.AddProduct("gold6", ProductType.Consumable, new IDs
        {
            {"gold6", GooglePlay.Name},
            {"gold6", AppleAppStore.Name}
        });
        builder.AddProduct("gold7", ProductType.Consumable, new IDs
        {
            {"gold7", GooglePlay.Name},
            {"gold7", AppleAppStore.Name}
        });
        builder.AddProduct("gold8", ProductType.Consumable, new IDs
        {
            {"gold8", GooglePlay.Name},
            {"gold8", AppleAppStore.Name}
        });
        builder.AddProduct("gold9", ProductType.Consumable, new IDs
        {
            {"gold9", GooglePlay.Name},
            {"gold9", AppleAppStore.Name}
        });
        builder.AddProduct("gold10", ProductType.Consumable, new IDs
        {
            {"gold10", GooglePlay.Name},
            {"gold10", AppleAppStore.Name}
        });
        builder.AddProduct("gold11", ProductType.Consumable, new IDs
        {
            {"gold11", GooglePlay.Name},
            {"gold11", AppleAppStore.Name}
        });
        builder.AddProduct("gold12", ProductType.Consumable, new IDs
        {
            {"gold12", GooglePlay.Name},
            {"gold12", AppleAppStore.Name}
        });
        UnityPurchasing.Initialize(this, builder);
    }


    // start the purchase process.
    public void Purchase(TableStore shopItem,Action<bool> callback)
    {
        Log("Purchaser Purchasing id:{0}", shopItem.StoreId);
        if (initSucess && m_Controller != null)
        {
            UIManager.Inst.showWaiting();
            Log("Purchaser ConfGoldShop :{0}", shopItem.StoreId);
            curShopItem = shopItem;
            m_Controller.InitiatePurchase(shopItem.StoreId);
        }
        else
        {
            UIManager.Inst.ShowMessage(LanguageTool.Get("pay_init_error"));
            StaticPurchaseFail();
            Purchaser.Inst.InitializePurchaser();
        }
    }

   

    private void Log(string info,params object[] args)
    {
        DebugUtil.Log(info, args);
    }

}