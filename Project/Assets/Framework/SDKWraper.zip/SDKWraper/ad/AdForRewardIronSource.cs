﻿using System;
using UnityEngine;


public class AdForRewardIronSource : IAd
{
    public static string ADEVENT_AdmobAdRewarded_Coin = "adevent_AdForCoin_adrewarded";
    public static string ADEVENT_AdLoaded = "adevent_AdForCoin_adloaded";

    public Action OnAdFinish;
    public Action OnAdOpen;
    public Action OnAdClose;

    private bool inited;
    private bool requesting;
    private bool closed = true;

    private bool _finishAd;

    public AdForRewardIronSource()
    {
        if (!inited)
        {
            Init();
        }
    }

    public void Init()
    {

        IronSourceEvents.onRewardedVideoAdOpenedEvent += RewardedVideoAdOpenedEvent;
        IronSourceEvents.onRewardedVideoAdClosedEvent += RewardedVideoAdClosedEvent;
        IronSourceEvents.onRewardedVideoAvailabilityChangedEvent += RewardedVideoAvailabilityChangedEvent;
        IronSourceEvents.onRewardedVideoAdStartedEvent += RewardedVideoAdStartedEvent;
        IronSourceEvents.onRewardedVideoAdEndedEvent += RewardedVideoAdEndedEvent;
        IronSourceEvents.onRewardedVideoAdRewardedEvent += RewardedVideoAdRewardedEvent;
        IronSourceEvents.onRewardedVideoAdShowFailedEvent += RewardedVideoAdShowFailedEvent;
        inited = true;
        Debug.Log("ADManager:Reward Request Init");
    }

    public void clear()
    {
        IronSourceEvents.onRewardedVideoAdOpenedEvent -= RewardedVideoAdOpenedEvent;
        IronSourceEvents.onRewardedVideoAdClosedEvent -= RewardedVideoAdClosedEvent;
        IronSourceEvents.onRewardedVideoAvailabilityChangedEvent -= RewardedVideoAvailabilityChangedEvent;
        IronSourceEvents.onRewardedVideoAdStartedEvent -= RewardedVideoAdStartedEvent;
        IronSourceEvents.onRewardedVideoAdEndedEvent -= RewardedVideoAdEndedEvent;
        IronSourceEvents.onRewardedVideoAdRewardedEvent -= RewardedVideoAdRewardedEvent;
        IronSourceEvents.onRewardedVideoAdShowFailedEvent -= RewardedVideoAdShowFailedEvent;
        inited = false;
    }


    public void Request()
    {

    }
    public bool IsLoaded()
    {
        return IronSource.Agent.isRewardedVideoAvailable();
    }

    private string _trigger;
    public void Show(Action callback = null, string trigger = "unknown")
    {
        try
        {
            _trigger = trigger;
            Debug.Log("unity-script: ShowRewardedVideoButtonClicked");
            if (IronSource.Agent.isRewardedVideoAvailable())
            {
                _finishAd = false;
                IronSource.Agent.showRewardedVideo();
            }
            else
            {
                Debug.Log("unity-script: IronSource.Agent.isRewardedVideoAvailable - False");
            }
        }
        catch (Exception e)
        {
            Debug.Log(e.Message);
        }
    }



    private void OnAdReward()
    {
        _finishAd = true;
        Debug.Log("ADManager:Ad Reward");
        if (OnAdFinish != null)
        {
            OnAdFinish();
            OnAdFinish = null;
            Debug.Log("ADManager:Ad Reward Sucess");
        }
        else
        {
            Debug.Log("ADManager:Ad Reward Fail");
        }
    }
    private void OnAdOpenFun()
    {
        Debug.Log("ADManager:Ad Open");
        if (OnAdOpen != null)
        {
            OnAdOpen();
            OnAdOpen = null;
            Debug.Log("ADManager:Ad Open sucess");
        }
        else
        {
            Debug.Log("ADManager:Ad Open fail");
        }
    }
    private void OnAdCloseFun()
    {
        Debug.Log("ADManager:Ad Close");
        if (OnAdClose != null)
        {
            OnAdClose();
            if (_finishAd)
            {
                _finishAd = false;
                OnAdClose = null;
            }
            Debug.Log("ADManager:Ad Close Sucess");
        }
        else
        {
            Debug.Log("ADManager:Ad Close Fail");
        }
    }

    //Invoked when the RewardedVideo ad view has opened.
    //Your Activity will lose focus. Please avoid performing heavy 
    //tasks till the video ad will be closed.
    void RewardedVideoAdOpenedEvent()
    {
        OnAdOpenFun();
        Debug.Log("AdForRewardIronSource :  RewardedVideoAdOpenedEvent");
    }
    //Invoked when the RewardedVideo ad view is about to be closed.
    //Your activity will now regain its focus.
    void RewardedVideoAdClosedEvent()
    {
        OnAdCloseFun();
        Debug.Log("AdForRewardIronSource :  RewardedVideoAdClosedEvent");
    }
    //Invoked when there is a change in the ad availability status.
    //@param - available - value will change to true when rewarded videos are available. 
    //You can then show the video by calling showRewardedVideo().
    //Value will change to false when no videos are available.
    void RewardedVideoAvailabilityChangedEvent(bool available)
    {
        Debug.Log("AdForRewardIronSource :  RewardedVideoAvailabilityChangedEvent available :" + available);
        //Change the in-app 'Traffic Driver' state according to availability.
        bool rewardedVideoAvailability = available;
    }
    //  Note: the events below are not available for all supported rewarded video 
    //   ad networks. Check which events are available per ad network you choose 
    //   to include in your build.
    //   We recommend only using events which register to ALL ad networks you 
    //   include in your build.
    //Invoked when the video ad starts playing.
    void RewardedVideoAdStartedEvent()
    {
        Debug.Log("AdForRewardIronSource :  RewardedVideoAdStartedEvent");
    }
    //Invoked when the video ad finishes playing.
    void RewardedVideoAdEndedEvent()
    {
        Debug.Log("AdForRewardIronSource :  RewardedVideoAdEndedEvent");
    }
    //Invoked when the user completed the video and should be rewarded. 
    //If using server-to-server callbacks you may ignore this events and wait for the callback from the  ironSource server.
    //
    //@param - placement - placement object which contains the reward data
    //
    void RewardedVideoAdRewardedEvent(IronSourcePlacement placement)
    {
        Debug.Log("AdForRewardIronSource :  RewardedVideoAdRewardedEvent");
        OnAdReward();
    }
    //Invoked when the Rewarded Video failed to show
    //@param description - string - contains information about the failure.
    void RewardedVideoAdShowFailedEvent(IronSourceError error)
    {
        Debug.Log("AdForRewardIronSource :  RewardedVideoAdShowFailedEvent");
    }
}