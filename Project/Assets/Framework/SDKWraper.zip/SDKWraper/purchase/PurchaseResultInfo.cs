﻿using System;
[System.Serializable]
public class PurchaseResultInfo
{
	public string productID;
	public string purchaseDate;
	public string transactionID;

	public PurchaseResultInfo ()
	{
	}
}

