﻿using System;
using UnityEngine;


public class AdForInterstitialIronSource : IAd
{
    public static string ADEVENT_AdmobAdRewarded_Coin = "adevent_AdForCoin_adrewarded";
    public static string ADEVENT_AdLoaded = "adevent_AdForCoin_adloaded";

    public Action OnAdOpen;
    public Action OnAdClose;

    private bool inited;
    private bool requesting;
    private bool closed = true;

    private bool _finishAd;

    public AdForInterstitialIronSource()
    {
        if (!inited)
        {
            Init();
        }
    }

    public void Init()
    {

        //IronSourceEvents.onInterstitialAdReadyEvent += InterstitialAdReadyEvent;
        //IronSourceEvents.onInterstitialAdLoadFailedEvent += InterstitialAdLoadFailedEvent;
        //IronSourceEvents.onInterstitialAdShowSucceededEvent += InterstitialAdShowSucceededEvent;
        //IronSourceEvents.onInterstitialAdShowFailedEvent += InterstitialAdShowFailedEvent;
        //IronSourceEvents.onInterstitialAdClickedEvent += InterstitialAdClickedEvent;
        //IronSourceEvents.onInterstitialAdOpenedEvent += InterstitialAdOpenedEvent;
        //IronSourceEvents.onInterstitialAdClosedEvent += InterstitialAdClosedEvent;

        inited = true;
        Debug.Log("ADManager:Interstitial Request Init");
    }

    public void clear()
    {
        //IronSourceEvents.onRewardedVideoAdOpenedEvent -= RewardedVideoAdOpenedEvent;
        //IronSourceEvents.onRewardedVideoAdClosedEvent -= RewardedVideoAdClosedEvent;
        //IronSourceEvents.onRewardedVideoAvailabilityChangedEvent -= RewardedVideoAvailabilityChangedEvent;
        //IronSourceEvents.onRewardedVideoAdStartedEvent -= RewardedVideoAdStartedEvent;
        //IronSourceEvents.onRewardedVideoAdEndedEvent -= RewardedVideoAdEndedEvent;
        //IronSourceEvents.onRewardedVideoAdRewardedEvent -= RewardedVideoAdRewardedEvent;
        //IronSourceEvents.onRewardedVideoAdShowFailedEvent -= RewardedVideoAdShowFailedEvent;
        //inited = false;
    }


    public void Request()
    {
        //IronSource.Agent.loadInterstitial();
    }
    public bool IsLoaded()
    {
        //return IronSource.Agent.isInterstitialReady();
        return false;
    }

    private string _trigger;
    public void Show(Action callback = null, string trigger = "unknown")
    {
        //try
        //{
        //    _trigger = trigger;
        //    Debug.Log("unity-script: ShowInterstitialVideoButtonClicked");
        //    if (IronSource.Agent.isInterstitialReady())
        //    {
        //        _finishAd = false;
        //        IronSource.Agent.showInterstitial();
        //    }
        //    else
        //    {
        //        Debug.Log("unity-script: IronSource.Agent.isInterstitialVideoAvailable - False");
        //    }
        //}
        //catch (Exception e)
        //{
        //    Debug.Log(e.Message);
        //}
    }


    private void OnAdOpenFun()
    {
        Debug.Log("AdForInterstitialIronSource:Ad Open");
        if (OnAdOpen != null)
        {
            OnAdOpen();
            OnAdOpen = null;
            Debug.Log("AdForInterstitialIronSource:Ad Open sucess");
        }
        else
        {
            Debug.Log("AdForInterstitialIronSource:Ad Open fail");
        }
    }
    private void OnAdCloseFun()
    {
        Debug.Log("AdForInterstitialIronSource:Ad Close");
        if (OnAdClose != null)
        {
            OnAdClose();
            OnAdClose = null;
            Debug.Log("AdForInterstitialIronSource:Ad Close Sucess");
        }
        else
        {
            Debug.Log("AdForInterstitialIronSource:Ad Close Fail");
        }
    }

    //Invoked when the initialization process has failed.
    //@param description - string - contains information about the failure.
    //void InterstitialAdLoadFailedEvent(IronSourceError error)
    //{
    //}
    //Invoked right before the Interstitial screen is about to open.
    void InterstitialAdShowSucceededEvent()
    {
    }
    //Invoked when the ad fails to show.
    //@param description - string - contains information about the failure.
    //void InterstitialAdShowFailedEvent(IronSourceError error)
    //{
    //}
    // Invoked when end user clicked on the interstitial ad
    void InterstitialAdClickedEvent()
    {
    }
    //Invoked when the interstitial ad closed and the user goes back to the application screen.
    void InterstitialAdClosedEvent()
    {
        OnAdCloseFun();
    }
    //Invoked when the Interstitial is Ready to shown after load function is called
    void InterstitialAdReadyEvent()
    {
    }
    //Invoked when the Interstitial Ad Unit has opened
    void InterstitialAdOpenedEvent()
    {
        OnAdOpenFun();
    }



}


