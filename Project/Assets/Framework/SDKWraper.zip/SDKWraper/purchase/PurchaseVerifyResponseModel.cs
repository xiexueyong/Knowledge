﻿using System;

[System.Serializable]
public class PurchaseVerifyResponseModel
{
	public int add_coin;
	public int coin;
	public string info;
	public bool noads;
	public string transactionID;

	public PurchaseVerifyResponseModel ()
	{
	}
}

