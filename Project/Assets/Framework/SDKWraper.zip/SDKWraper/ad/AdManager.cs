﻿using System;
using UnityEngine;


public enum AdType
{
    Reward = 1,
    Interstitial = 2
}
public class AdManager
{
    public int LastShowAdTime;
    // public string AppId;
    //public string banner_adUnitId;
    //public string interstitial_adUnitId;
    //public string reward1_adUnitId;
    //public string reward2_adUnitId;
    /// <summary>
    /// The ad for coin.
    /// </summary>
	public AdForRewardIronSource _adForReward;
    public AdForRewardIronSource adForReward
    {
        get {
            if (_adForReward == null) {
                _adForReward = new AdForRewardIronSource();
            }
            return _adForReward;
        }
    }

    /// <summary>
    /// The ad banner view.
    /// </summary>
    //private AdBannerView _adBannerView;
    //public AdBannerView adBannerView {
    //    get {
    //        if (_adBannerView == null) {
    //            _adBannerView = new AdBannerView();
    //        }
    //        return _adBannerView;
    //    }
    //}

    /// <summary>
    /// The ad banner view.
    /// </summary>
    private AdForInterstitialIronSource _adInterstitial;
    public AdForInterstitialIronSource adInterstitial
    {
        get
        {
            //if (_adInterstitial == null)
            //{
            //    _adInterstitial = new AdForInterstitialIronSource();
            //}
            return _adInterstitial;
        }
    }


    public AdManager()
    {
    }
    public void Init() {

#if UNITY_ANDROID
        string appKey = "c5fb754d";//PolarBlast：c5fb754d, TomBlast：aeb1553d
#elif UNITY_IPHONE || UNITY_IOS
        string appKey = "d0eefba5";
#else
        string appKey = "unexpected_platform";
#endif
        IronSource.Agent.init(appKey);
        IronSource.Agent.validateIntegration();

        if(adForReward != null)
        {

        }
        //if (adInterstitial != null)
        //{
        //    adInterstitial.Request();
        //}


    }

    private static AdManager _instance;
    public static AdManager Instance {
        get {
            if (_instance == null) {
                _instance = new AdManager();
            }
            return _instance;
        }
    }


    //广告恢复时间
    //public int StartRecoverRewardAd{
    //    get { return PlayerPrefs.GetInt("StartRecoverRewardAd", 0);}
    //    set { PlayerPrefs.SetInt("StartRecoverRewardAd", value);}
    //}
    //private int AdRecoverSpan = 300;
    //public bool AdRecoverd()
    //{
    //    if (SystemClock.Instance.Now - StartRecoverRewardAd < AdRecoverSpan)
    //    {
    //        return false;
    //    }
    //    return true;
    //}
    //public void ConsumeAd()
    //{
    //    StartRecoverRewardAd = (int)SystemClock.Instance.Now;
    //}

    //public int getRecoverTime()
    //{
    //    if (!AdRecoverd())
    //    {
    //        return AdRecoverSpan - (int)(SystemClock.Instance.Now - StartRecoverRewardAd);
    //    }
    //    return 0;
    //}




    public void ShowRewardAd(Action OnADOpen,Action OnRewardSucess, Action<int> OnAdClose = null, Action OnAdFail = null, string _trigger = "unknown")
    {

        if (GameConfig.Inst.RewardSucess)
        {
            if(OnRewardSucess != null)
                OnRewardSucess();
            return;
        }

        int startTime = 0;
        if (AdManager.Instance.adForReward.IsLoaded())
        {
            bool isMusicOpen = SoundPlay.isMusicOpen;
            bool isSoundOpen = SoundPlay.isSoundOpen;

            Debug.Log("AdManager:ShowRewardAd");
            AdManager.Instance.adForReward.OnAdOpen = () =>
            {

                LastShowAdTime = startTime = SystemClock.Now;
                SoundPlay.isMusicOpen = false;
                SoundPlay.isSoundOpen = false;
                OnADOpen?.Invoke();
            };
            bool finishAd = false;
            bool closedAd = false;
            bool givenAdReward = false;
            AdManager.Instance.adForReward.OnAdFinish = () =>
            {
                Debug.Log("AdManager:OnRewardSucess1");
                finishAd = true;
                if (!givenAdReward && closedAd)
                {
                    givenAdReward = true;
                    OnRewardSucess?.Invoke();
                }
            };
  
            AdManager.Instance.adForReward.OnAdClose = () =>
            {
                closedAd = true;
                SoundPlay.isMusicOpen = isMusicOpen;
                SoundPlay.isSoundOpen = isSoundOpen;
                OnAdClose?.Invoke(SystemClock.Now-startTime);
                if (finishAd && !givenAdReward)
                {
                    givenAdReward = true;
                    OnRewardSucess?.Invoke();
                }
            };
            AdManager.Instance.adForReward.Show(null,_trigger);
        }
        else
        {
            OnAdFail?.Invoke();
            UIManager.Inst.ShowMessage(LanguageTool.Get("no_ad_tip"));
        }
    }



    public void ShowInterstitialAd(Action OnADOpen = null, Action<int> OnAdClose = null, Action OnAdFail = null, string _trigger = "unknown")
    {
        //if (AdManager.Instance.adInterstitial.IsLoaded())
        //{
        //    bool isMusicOpen = SoundPlay.isMusicOpen;
        //    bool isSoundOpen = SoundPlay.isSoundOpen;
        //    int startTime = 0;
        //    Debug.Log("AdManager:ShowRewardAd");
        //    AdManager.Instance.adInterstitial.OnAdOpen = () =>
        //    {
        //        SoundPlay.isMusicOpen = false;
        //        SoundPlay.isSoundOpen = false;
        //        LastShowAdTime = startTime = SystemClock.Now;
        //        if (OnADOpen != null)
        //        {
        //            OnADOpen();
        //        }
        //    };

        //    AdManager.Instance.adInterstitial.OnAdClose = () =>
        //    {
        //        SoundPlay.isMusicOpen = isMusicOpen;
        //        SoundPlay.isSoundOpen = isSoundOpen;
        //        if (OnAdClose != null)
        //        {
        //            OnAdClose(SystemClock.Now-startTime);
        //        }
        //        adInterstitial.Request();
        //    };
        //    AdManager.Instance.adInterstitial.Show(null, _trigger);
        //}
        //else
        //{
        //    if (OnAdFail != null)
        //    {
        //        OnAdFail();
        //        DebugUtil.Log("no ad Interstitial now");
        //        adInterstitial.Request();
        //    }
       
        //}
    }


}