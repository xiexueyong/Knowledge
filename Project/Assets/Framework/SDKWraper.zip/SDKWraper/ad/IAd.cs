﻿using System;
public interface IAd
{
	//请求
	void Request();
	//初始化
	void Init ();
	//是否请求到
	bool IsLoaded ();
	//显示
	void Show (Action callback = null,string trigger = "unknown");
}